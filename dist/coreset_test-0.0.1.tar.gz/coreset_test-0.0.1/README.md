# Coresets-Tests
This repository contains a new method to test your coreset, using backpropagation. 

### Install
```
pip install git+https://github.com/BenMussay/Coresets-Tests/
```

## Citations
