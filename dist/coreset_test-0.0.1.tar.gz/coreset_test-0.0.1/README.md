# Coresets-Tests
This repository contains a new method to test your coreset, using backpropagation. 

## Citations
