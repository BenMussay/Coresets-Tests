name = "coreset_test"

from . import coreset_test
